import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose

class TurtlePoseSubscriber(Node):
    def __init__(self):
        super().__init__('turtle_pose_subscriber')
        # /turtle1/pose 토픽을 구독
        self.subscription = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.listener_callback,
            10)

    def listener_callback(self, msg):
        # 속도(linear_velocity, angular_velocity)를 제외한 위치와 각도만 출력
        self.get_logger().info(f'Pose: x={msg.x:.2f}, y={msg.y:.2f}, theta={msg.theta:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = TurtlePoseSubscriber()
    rclpy.spin(node) # 사용자가 종료할 때까지 구독
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()