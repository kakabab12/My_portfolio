import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CircleTurtleNode(Node):
    def __init__(self):
        super().__init__('circle_turtle_node')
        # 퍼블리셔 생성: 토픽명, 메시지 타입, 큐 사이즈
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        
        # 0.1초마다 실행되는 타이머
        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        msg = Twist()
        msg.linear.x = 2.0  # 전진 속도
        msg.angular.z = 1.8 # 회전 속도 (이 값이 클수록 원이 작아짐)
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: linear.x=2.0, angular.z=1.8')

def main(args=None):
    rclpy.init(args=args)
    node = CircleTurtleNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()