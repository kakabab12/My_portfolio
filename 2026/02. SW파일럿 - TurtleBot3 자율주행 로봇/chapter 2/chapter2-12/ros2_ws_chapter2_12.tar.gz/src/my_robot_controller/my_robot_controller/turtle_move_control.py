import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import Kill
from std_srvs.srv import Empty

class TurtleMoveControl(Node):
    def __init__(self):
        super().__init__('turtle_move_control')
        
        # 토픽 퍼블리셔 및 서브스크라이버 설정
        self.cmd_vel_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.pose_sub = self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        
        # 1. 외부에서 종료 명령을 받을 /quit 서비스 서버 생성
        self.quit_server = self.create_service(Empty, '/quit', self.quit_callback)
        
        # 2. turtlesim의 로봇을 지우기 위한 /kill 서비스 클라이언트 생성
        self.kill_client = self.create_client(Kill, '/kill')
        
        self.get_logger().info("비동기 서비스 제어형 Turtle Move Control Node가 가동되었습니다.")

    def pose_callback(self, pose: Pose):
        """ 거북이가 벽에 충돌하지 않도록 실시간 위치 피드백 제어 """
        cmd = Twist()
        if pose.x < 2.0 or pose.x > 9.0 or pose.y < 2.0 or pose.y > 9.0:
            cmd.linear.x = 1.0
            cmd.angular.z = 1.4
        else:
            cmd.linear.x = 2.2
            cmd.angular.z = 0.0
        self.cmd_vel_pub.publish(cmd)

    def quit_callback(self, request, response):
        """ /quit 서비스를 수신했을 때 실행되는 콜백 함수 """
        self.get_logger().info("==> [/quit] 신호 감지: 주행을 유지하며 /kill 서비스를 백그라운드 호출합니다.")
        
        if not self.kill_client.service_is_ready():
            self.kill_client.wait_for_service(timeout_sec=1.0)
            
        kill_req = Kill.Request()
        kill_req.name = 'turtle1'
        
        # call_async를 사용하여 응답을 기다리는 동안에도 주행 스레드가 제 기능을 수행함
        future = self.kill_client.call_async(kill_req)
        future.add_done_callback(self.kill_done_callback)
        
        return response

    def kill_done_callback(self, future):
        """ /kill 서비스의 응답 처리가 완료되었을 때 실행되는 콜백 """
        try:
            future.result()
            self.get_logger().info("==> turtlesim 시뮬레이터에서 'turtle1'을 성공적으로 제거했습니다.")
        except Exception as e:
            self.get_logger().error(f"/kill 서비스 호출 실패: {e}")
        
        self.get_logger().info("모든 예외 처리 검증 완료. 시스템을 클린 셧다운합니다.")
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = TurtleMoveControl()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
